
# required R packages
if(!require(pacman)) install.packages("pacman");
pacman::p_load(here, 
               sf,
               data.table,
               glue, 
               ggplot2,
               ggspatial,
               patchwork,
               RColorBrewer,
               ggpubr,
               gridExtra,
               grid,
               cowplot,
               openxlsx,
               install = TRUE)

# this will point to the directory where the .csv files are saved and the 'district_polygons.geojson' file
def_dir = here::here()

# create a folder to save the output results
dir_save_plt = file.path(def_dir, 'plot_excel_results')
if (!dir.exists(dir_save_plt)) dir.create(dir_save_plt)

# the vector of the names
vec_csv = c('CAT.csv',
            'LGB.csv',
            'RF.csv',
            'XG.csv')
vec_csv = gsub(pattern = '.csv', replacement = '_rmse.csv', x = vec_csv)

# path of the geojson file with the districts
pth_geojson = file.path(dirname(def_dir), 'district_polygons.geojson')

# iterate over the input .csv files and save the output multi-plot and excel
for (item in vec_csv) {
  
  # create a directory to save the .xlsx file & .png image
  pth_item = file.path(def_dir, item)

  name_alg = gsub(pattern = '_rmse.csv', replacement = '', x = item) |>
    trimws(which = 'both')
  
  dir_ml = file.path(dir_save_plt, name_alg)
  if (!dir.exists(dir_ml)) dir.create(dir_ml)
  
  if (name_alg == 'CAT') {
    NAME = 'Catboost'
  } else if (name_alg == 'LGB') {
    NAME = 'LightGBM'
  } else if (name_alg == 'RF') {
    NAME = 'Random Forest'
  } else if (name_alg == 'XG') {
    NAME = 'XGBoost'
  }
  
  if (!file.exists(pth_item)) stop(glue::glue("The file '{pth_item}' does not exist!"))
  dat_item = data.table::fread(file = pth_item, header = T, stringsAsFactors = F)
  
  dat_sf = sf::st_as_sf(dat_item, coords = c('Longitude', 'Latitude'), crs = 4326)
  dat_gj = sf::st_read(pth_geojson, quiet = TRUE)
  
  districts = sf::st_join(y = dat_sf, x = dat_gj[, 'geometry'], left = F)
  
  # Calculate global min and max RMSE across all years
  rmse_min <- min(c(
    districts$`2019`, districts$`2020`, 
    districts$`2021`, districts$`2022`, 
    districts$`2023`
  ))
  rmse_max <- max(c(
    districts$`2019`, districts$`2020`, 
    districts$`2021`, districts$`2022`, 
    districts$`2023`
  ))
  
  # Common theme for all plots
  map_theme <- theme_minimal() +
    theme(legend.position = "bottom",  # Remove individual legends
          plot.title = element_text(size = 10, face = "bold"))
  
  # Function to create individual plots
  create_map <- function(data, year, title, add_arrow = FALSE, add_scale = FALSE) {
    p <- ggplot() +
      geom_sf(data = data, aes(fill = .data[[year]])) +
      scale_fill_distiller(
        palette = "Greens",
        name = "RMSE",
        limits = c(rmse_min, rmse_max),
        direction = 1
      ) +
      map_theme +
      ggtitle(title)
    
    # Add scale bar only to specific plots
    if (add_scale) {
      p <- p + annotation_scale(
        location = "bl",
        width_hint = 0.3,
        pad_x = unit(0.2, "cm"),
        pad_y = unit(0.2, "cm")
      )
    }
    
    # Add north arrow only to the specified plot
    if(add_arrow) {
      p <- p + annotation_north_arrow(
        location = "br",
        which_north = "true",
        pad_x = unit(0.2, "cm"),
        pad_y = unit(0.5, "cm"),
        style = north_arrow_fancy_orienteering
      )
    }
    return(p)
  }
  
  # Create individual plots (no scales; arrow only on the last plot)
  plot_2019 <- create_map(districts, "2019", "2019")
  plot_2020 <- create_map(districts, "2020", "2020")
  plot_2021 <- create_map(districts, "2021", "2021")
  plot_2022 <- create_map(districts, "2022", "2022")
  plot_2023 <- create_map(districts, "2023", "2023")
  
  # Create the empty space plot (6th subplot) with title, scale, and legend
  legend_plot <- ggplot() +
    geom_sf(data = districts, aes(fill = `2019`)) +
    scale_fill_distiller(
      palette = "Greens",
      name = "RMSE",
      limits = c(rmse_min, rmse_max),
      direction = 1
    ) +
    theme_void() +
    theme(legend.position = "bottom")
  
  shared_legend <- cowplot::get_legend(legend_plot)
  
  # Empty subplot with scale bar and legend
  empty_space <- ggplot() +
    annotation_custom(grid::textGrob(glue::glue("RMSE by District Across Years\n based on '{NAME}'"), 
                                     gp = grid::gpar(fontsize = 12, fontface = "bold")),
                      ymin = 0, ymax = 1, xmin = 0, xmax = 1) +
    theme_void() +
    annotation_scale(
      location = "bl", 
      width_hint = 0.3
    ) +
    annotation_north_arrow(
      location = "br", 
      which_north = "true", 
      style = north_arrow_fancy_orienteering
    )
  
  # Combine plots using patchwork
  combined_plot <- (plot_2019 + plot_2020 + plot_2021 + 
                      plot_2022 + plot_2023 + empty_space) +
    plot_layout(ncol = 3)
  
  # Add shared legend below the combined plot
  final_plot <- cowplot::plot_grid(combined_plot, shared_legend, 
                                   ncol = 1, rel_heights = c(9, 1))
  # # Display the final plot
  # print(final_plot)
  
  # save the excel file
  districts_df = sf::st_drop_geometry(districts)
  openxlsx::write.xlsx(x = districts_df, file = file.path(dir_ml, gsub(pattern = '.csv', replacement = '.xlsx', x = item)))
  
  ggplot2::ggsave(filename = file.path(dir_ml, gsub(pattern = '.csv', replacement = '.png', x = item)), 
                  plot = final_plot, 
                  width = 20, 
                  height = 15)
}

